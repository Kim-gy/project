//dragndrop 파일업로드
(function ($) {
	/*
	 * var objDnd = $("#list1").jgdragndrop({
		options:{maxFileNum:3,availExt:["hwp","pdf","gif"]},
		arrFiles:[{filename:"test1.txt",filesize:100,filesn:1}]
	});
	 */
	"use strict";
	$.jgdragndrop = $.jgdragndrop || {};
	
	$.fn.jgdragndrop = function(opt) {
		
		var opt = opt || {};
		
		//옵션 - maxFileNum : 첨부가능한 파일수, availExt : 첨부가능한 확장자 배열.
		var options = opt.options || {
			maxFileNum:1,
			availExt:[]
		};
		//기존 첨부된 파일 배열
		
		//this.getGridParam("test");
		
		var arrFiles = opt.arrFiles || [];
		
		var stayFiles = new Array(); //드래그앤드롭된 파일배열
		var stayStatus = new Array(); //드래그앤드롭된 파일상태표시배열
		var fd = new FormData();//드래그앤드롭된 파일 정보가 있는 폼데이타 객체
		
		
		
		
		var fileTotCnt=0;
		var rowCount=0;
		var totalSize = 0;
		var fileCnt = 0;

		
		var obj = this;
		
		//setDefaultFiles();
		
		
		obj.on('dragenter', function (e) 
		{
		   e.stopPropagation();
		   e.preventDefault();
		   obj.css('border', '2px solid #0B85A1');
		});
		obj.on('dragover', function (e) 
		{
			e.stopPropagation();
			e.preventDefault();
		});
		obj.on('drop', function (e) 
		{

			obj.css('border', '2px dotted #0B85A1');
			e.preventDefault();
			var files = e.originalEvent.dataTransfer.files;

			handleFileUpload(files,obj);
		});
		

		 var getFileSize = function(){
			return  fileCnt;
		 };
		   
		 var handleFileUpload = function(files,obj){
			 for (var i = 0; i < files.length; i++) 
			 {
				  var fileInfo = files[i].name.split(".");
				  //fd.append('file[]', files[i]);
				  fd.append('file'+fileCnt, files[i]);
		   
				  var status = new createStatusbar(obj);
				  status.setFileNameSize(files[i].name,files[i].size);
				  stayFiles.push(fd);
				  stayStatus.push(status);
				  totalSize += files[i].size;
				  fileCnt++;		   
			 }
		 };
		 
		 var createStatusbar = function(obj){
			 if(obj.find(".fileStatus").children().size() == 0){
				 obj.find(".fileStatus").html("");
			 }
			 rowCount++;
			 var row="odd";
			 if(rowCount %2 ==0) row ="even";
			 this.statusbar = $("<div class='statusbar "+row+"' rowid='"+rowCount+"'></div>");
			 this.filename = $("<div class='filename'></div>").appendTo(this.statusbar);
			 this.size = $("<div class='filesize'></div>").appendTo(this.statusbar);
			 this.progressBar = $("<div class='progressBar'><div></div></div>").appendTo(this.statusbar);
			 this.abort = $("<div class='abort' onclick='delFile(this)'>삭제</div>").appendTo(this.statusbar);
			 obj.find(".fileStatus").append(this.statusbar);
			 this.progressPercent = 0;
			 this.setSn = function(sn)
			 {
				 this.statusbar.attr("sn", sn);
			 }
			 this.setFileNameSize = function(name,size)
			 {
				 var sizeStr="";
				 var sizeKB = size/1024;
				 if(parseInt(sizeKB) > 1024)
				 {
					 var sizeMB = sizeKB/1024;
					 sizeStr = sizeMB.toFixed(2)+" MB";
				 }
				 else
				 {
					 sizeStr = sizeKB.toFixed(2)+" KB";
				 }
		  
				 this.filename.html(name);
				 this.size.html(sizeStr);
				 this.statusbar.attr("filesize", size);
			 }
			 this.setProgress = function(progress)
			 {
				this.progressPercent = progress;
				 var progressBarWidth =progress*this.progressBar.width()/ 100;  
				 this.progressBar.find('div').animate({ width: progressBarWidth }, 10).html(progress + "% ");
			 }
			 this.getProgress = function()
			 {
				return this.progressPercent;
			 }
		 };
		 
		 setInitFile();
		 function setInitFile(){
			 
				for (var i = 0; i < arrFiles.length; i++) 
				 {
					var fileInfo = arrFiles[i];
					//alert("fileInfo:"+fileInfo);
					if(obj.find(".fileStatus").children().size() == 0){
						obj.find(".fileStatus").html("");
					}
					
					var statusbar = $("<div class='statusbar1' rowid='sn_"+i+"' filesn='"+fileInfo.filesn+"' ></div>");
					var filename = $("<div class='filename1'>"+fileInfo.filename+"</div>").appendTo(statusbar);
					var size = $("<div class='filesize'>"+getFileSizeName(fileInfo.filesize)+"</div>").appendTo(statusbar);
					$("<div class='abort' onclick='delFile(this)'>삭제</div>").appendTo(statusbar);
					obj.find(".fileStatus").append(statusbar);
				 }
		 };
		 
		 
		 function getFileSizeName(size){
			 
			 var sizeStr="";
			 var sizeKB = size/1024;
			 if(parseInt(sizeKB) > 1024)
			 {
				 var sizeMB = sizeKB/1024;
				 sizeStr = sizeMB.toFixed(2)+" MB";
			 }
			 else
			 {
				 sizeStr = sizeKB.toFixed(2)+" KB";
			 }			 
			 return sizeStr;
		 }
		 
		 
		return {			
			getFileTotCnt:function(){return fileTotCnt;},
			getFileCnt:function(){return fileCnt;},
			getTotalSize:function(){return totalSize;},			
			getStayFiles:function(){return stayFiles;},
			getStayStatus:function(){return stayStatus;},
			getFormData:function(){return fd;}
			,setData:function(){
				fileTotCnt=0;
				rowCount=0;
				totalSize = 0;
				fileCnt = 0;
				stayFiles = new Array(); //드래그앤드롭된 파일배열
				stayStatus = new Array(); //드래그앤드롭된 파일상태표시배열
				fd = new FormData();//드래그앤드롭된 파일 정보가 있는 폼데이타 객체
				obj.find(".fileStatus").html("");
			}
			
		};
	};

	
}(jQuery));