package com.neo.convergence.mngr.sample.service;

import java.util.List;

import com.neo.convergence.mngr.sample.model.SampleVO;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.mngr.sample.service.SampleService<br>
 * 클래스 설명 : 샘플 Interface
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
public interface SampleService {

    /**
     * 샘플 개수 조회
     * @param sampleVO - 검색 조건이 담긴 VO
     * @return 샘플 개수
     */
    public int selectCntSample(SampleVO sampleVO);

    /**
     * 샘플 목록 조회
     * @param sampleVO - 검색 조건이 담긴 VO
     * @return 샘플 목록
     */
    public List<SampleVO> selectSampleList(SampleVO sampleVO);

    /**
     * 샘플 조회
     * @param sampleVO - 검색 조건이 담긴 VO
     * @return 샘플
     */
    public SampleVO selectSample(SampleVO sampleVO);

    /**
     * 샘플 등록
     * @param sampleVO - 샘플 등록 데이터가 담긴 VO
     * @return 등록 개수
     */
    public int insertSample(SampleVO sampleVO);

    /**
     *
     * @param sampleVO - 샘플 수정 데이터가 담긴 VO
     * @return 수정 개수
     */
    public int updateSample(SampleVO sampleVO);
}