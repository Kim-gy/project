package com.neo.convergence.mngr.board.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.board.dao.MemberDao;
import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.model.MemberVo;
import com.neo.convergence.mngr.board.service.MemberService;
import com.neo.convergence.mngr.sample.service.impl.SampleServiceImpl;

@Service("memberService")
public class MemberServiceimpl implements MemberService {

	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(SampleServiceImpl.class);

	/** sampleDAO */
	@Resource(name = "memberDao")
	private MemberDao dao;

	@Override
	public void insert(MemberVo vo) throws Exception {
		// TODO Auto-generated method stub

		// 이메일 합쳐서 설정
		vo.setEmail(vo.getEmail1() + vo.getEmail2());
		// 생일 설정시 8자리를 위한 설정
		if (Integer.parseInt(vo.getMon()) < 10)
			vo.setMon(0 + vo.getMon());
		if (Integer.parseInt(vo.getDay()) < 10)
			vo.setDay(0 + vo.getDay());
		vo.setBirth(vo.getYear() + vo.getMon() + vo.getDay());
		// 번호를 합쳐서 설정
		vo.setPhone(
				Integer.toString(vo.getPhone1()) + Integer.toString(vo.getPhone2()) + Integer.toString(vo.getPhone3()));
		System.out.println("--------------------------------------" + vo.getPw());
		dao.insert(vo);
	}

	@Override
	public void update(MemberVo vo) throws Exception {
		// TODO Auto-generated method stub
		dao.update(vo);
	}

	@Override
	public void delete(String id) throws Exception {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public MemberVo login(MemberVo vo) throws Exception {
		// TODO Auto-generated method stub
		return dao.login(vo);
	}

	@Override
	public boolean idchek(String id) throws Exception {
		// TODO Auto-generated method stub
		return dao.idcheck(id);
	}

	@Override
	public List<MemberVo> list(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return dao.list(cri);
	}

	@Override
	public int count(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return dao.count(cri);
	}

	@Override
	public MemberVo read(String id) throws Exception {
		// TODO Auto-generated method stub
		return dao.read(id);
	}

	@Override
	public void admin(String id) throws Exception {
		// TODO Auto-generated method stub
		dao.admin(id);
	}

	@Override
	public void user(String id) throws Exception {
		// TODO Auto-generated method stub
		dao.user(id);
	}

	@Override
	public int authority(String id) throws Exception {
		// TODO Auto-generated method stub
		return dao.authority(id);
	}

	@Override
	public int totla() throws Exception {
		// TODO Auto-generated method stub
		return dao.total();
	}

}
