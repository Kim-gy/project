package com.neo.convergence.mngr.bcnc.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * ���ㅽ��紐� : �����ъ��-��濡�����2<br>
 * com.neo.convergence.mngr.sample.model.SampleVO<br>
 * �대���� �ㅻ� : ���� VO
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 媛����대��(Modification Infomation) >>
 *
 *      ������       ������              �����댁��
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     理�珥�����
 * </pre>
 */
public class BcncVO {
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

    // 寃���
    /** 寃���-寃���議곌굔 */
    private String searchCondition;
    /** 寃���-寃����� */
    private String searchKeyword;

    // 怨듯��
    /** 행번호 */
    private String rnum;
    /** 踰��� */
    private String no;

    private long bcncSn;
    private String bcncNm;
    private String bsnmRegistNo;
    private String fndtnzDe;
    private String useAt;
    private String registDt;
    private String registerId;
    private String updtDt;
    private String updusrId;

    public String getSearchCondition() {
        return searchCondition;
    }
    public void setSearchCondition(String searchCondition) {
        this.searchCondition = searchCondition;
    }
    public String getSearchKeyword() {
        return searchKeyword;
    }
    public void setSearchKeyword(String searchKeyword) {
        this.searchKeyword = searchKeyword;
    }
    public String getRnum() {
        return rnum;
    }
    public void setRnum(String rnum) {
        this.rnum = rnum;
    }
    public String getNo() {
        return no;
    }
    public void setNo(String no) {
        this.no = no;
    }
	public long getBcncSn() {
		return bcncSn;
	}
	public void setBcncSn(long bcncSn) {
		this.bcncSn = bcncSn;
	}
	public String getBcncNm() {
		return bcncNm;
	}
	public void setBcncNm(String bcncNm) {
		this.bcncNm = bcncNm;
	}
	public String getBsnmRegistNo() {
		return bsnmRegistNo;
	}
	public void setBsnmRegistNo(String bsnmRegistNo) {
		this.bsnmRegistNo = bsnmRegistNo;
	}
	public String getFndtnzDe() {
		return fndtnzDe;
	}
	public void setFndtnzDe(String fndtnzDe) {
		this.fndtnzDe = fndtnzDe;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}
	public String getRegistDt() {
		return registDt;
	}
	public void setRegistDt(String registDt) {
		this.registDt = registDt;
	}
	public String getRegisterId() {
		return registerId;
	}
	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}
	public String getUpdtDt() {
		return updtDt;
	}
	public void setUpdtDt(String updtDt) {
		this.updtDt = updtDt;
	}
	public String getUpdusrId() {
		return updusrId;
	}
	public void setUpdusrId(String updusrId) {
		this.updusrId = updusrId;
	}
}