package com.neo.convergence.mngr.board.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.neo.convergence.mngr.board.model.DeptVo;
import com.neo.convergence.mngr.board.model.MemberVo;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("deptDao")
public class DeptDao extends EgovAbstractMapper {

	public void insert(DeptVo vo) throws Exception {
		insert("Dept.insert", vo);
	}

	public void newLedaer(DeptVo vo) throws Exception {
		update("Dept.newLeader", vo);
	}

	public List<DeptVo> Parent() throws Exception {
		return selectList("Dept.parent");

	}

	public List<DeptVo> upper(int id) throws Exception {
		return selectList("Dept.upper", id);

	}

	public void newMem(MemberVo vo) throws Exception {

		update("Dept.newMem", vo);
	}

	public DeptVo me(int id) throws Exception {
		return selectOne("Dept.me", id);
	}

	public List<MemberVo> allMem(int deptId) throws Exception {
		return selectList("Dept.allMem", deptId);

	}

	public void deptChange(String id) throws Exception {

		update("Dept.deptchange", id);

	}

}
