package com.neo.convergence.mngr.board.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.board.dao.BoardDao;
import com.neo.convergence.mngr.board.dao.CommentDao;
import com.neo.convergence.mngr.board.model.BoardVo;
import com.neo.convergence.mngr.board.model.CommentVo;
import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.service.BoardService;
import com.neo.convergence.mngr.board.web.BoardController;

@Service("boardService")
public class BoardServiceimpl implements BoardService {

	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(BoardController.class);

	@Resource(name = "boardDAO")
	private BoardDao dao;

	@Resource(name = "commentDAO")
	private CommentDao com;

	@Override
	public void seq(int bno) throws Exception {
		// TODO Auto-generated method stub

		dao.seq(bno);
	}

	@Override
	public void write(BoardVo vo) throws Exception {
		// TODO Auto-generated method stub
		dao.write(vo);
	}

	@Override
	public void writeRe(BoardVo vo) throws Exception {
		// TODO Auto-generated method stub

		dao.writeRe(vo);
	}

	@Override
	public void update(BoardVo vo) throws Exception {
		// TODO Auto-generated method stub
		dao.update(vo);

	}

	@Override
	public String check(int bno) throws Exception {
		// TODO Auto-generated method stub

		return dao.check(bno);

	}

	@Override
	public List<BoardVo> boardList(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return dao.boardList(cri);
	}

	@Override
	public int ListCount(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return dao.ListCount(cri);

	}

	@Override
	public int refbno(int bno) throws Exception {
		// TODO Auto-generated method stub
		return dao.refbno(bno);
	}

	@Override
	public BoardVo read(int bno) throws Exception {

		return dao.read(bno);
	}

	@Override
	public void delete(int bno) throws Exception {
		// TODO Auto-generated method stub
		dao.delete(bno);
	}

	@Override
	public void deleteRef(int bno) throws Exception {
		// TODO Auto-generated method stub
		dao.deleteRef(bno);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CommentVo> listComment(Integer refbno) throws Exception {
		// TODO Auto-generated method stub
		return com.listComment(refbno);
	}

	@Override
	public void deleteCas(int bno) throws Exception {
		// TODO Auto-generated method stub
		com.deleteCas(bno);
	}

	@Override
	public int count() throws Exception {
		return dao.count();

	}

	@Override
	public List listComment(Object refbno) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List listComment() {
		// TODO Auto-generated method stub
		return null;
	}
}
