package com.neo.convergence.mngr.board.service;

import java.util.List;

import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.model.MemberVo;

public interface MemberService {

	public void insert(MemberVo vo) throws Exception;

	public void update(MemberVo vo) throws Exception;

	public void delete(String id) throws Exception;

	public MemberVo login(MemberVo vo) throws Exception;

	public boolean idchek(String id) throws Exception;

	public List<MemberVo> list(Criteria cri) throws Exception;

	public int count(Criteria cri) throws Exception;

	public int authority(String id) throws Exception;

	public MemberVo read(String id) throws Exception;

	public void admin(String id) throws Exception;

	public void user(String id) throws Exception;

	public int totla() throws Exception;
}
