package com.neo.convergence.mngr.board.model;

import java.sql.Date;

public class CommentVo {
	private Integer refbno;
	private Integer cno;
	private String writer;
	private String content;
	private Date regdate;
	private String password;

	public int getRefbno() {
		return refbno;
	}

	public void setRefbno(Integer refbno) {
		this.refbno = refbno;
	}

	public int getCno() {
		return cno;
	}

	public void setCno(Integer cno) {
		this.cno = cno;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
