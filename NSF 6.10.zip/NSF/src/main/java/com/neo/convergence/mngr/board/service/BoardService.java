package com.neo.convergence.mngr.board.service;

import java.util.List;

import com.neo.convergence.mngr.board.model.BoardVo;
import com.neo.convergence.mngr.board.model.CommentVo;
import com.neo.convergence.mngr.board.model.Criteria;

public interface BoardService<integer> {

	public void seq(int bno) throws Exception;

	public void write(BoardVo vo) throws Exception;

	public void update(BoardVo vo) throws Exception;

	public String check(int bno) throws Exception;

	public List<BoardVo> boardList(Criteria cri) throws Exception;

	public int ListCount(Criteria cri) throws Exception;

	public int refbno(int bno) throws Exception;

	public BoardVo read(int bno) throws Exception;

	public void delete(int bno) throws Exception;

	public void deleteRef(int bno) throws Exception;

	public List<CommentVo> listComment(integer refbno) throws Exception;

	public void deleteCas(int bno) throws Exception;

	public void writeRe(BoardVo vo) throws Exception;

	public int count() throws Exception;

	List<CommentVo> listComment();

	List<CommentVo> listComment(Integer refbno) throws Exception;


}
