package com.neo.convergence.mngr.board.service;

import java.util.List;
import java.util.Map;

import com.neo.convergence.mngr.board.model.DeptVo;
import com.neo.convergence.mngr.board.model.MemberVo;

public interface DeptService {
	public void insert(DeptVo vo) throws Exception;

	public void newLedaer(DeptVo vo) throws Exception;

	public List<DeptVo> Parent() throws Exception;

	public List<DeptVo> upper(int deptId) throws Exception;

	public void newMem(MemberVo vo) throws Exception;

	public DeptVo me(int id) throws Exception;

	public List<MemberVo> allMem(int deptId) throws Exception;

	public Map<String, DeptVo> tree(int deptId) throws Exception;

	public void deptChange(String id) throws Exception;
}
