package com.neo.convergence.mngr.board.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.neo.convergence.mngr.board.model.BoardVo;
import com.neo.convergence.mngr.board.model.Criteria;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("boardDAO")
public class BoardDao extends EgovAbstractMapper {
	String namespace = "Board";

	public void seq(int bno) throws Exception {
		// TODO Auto-generated method stub

		update("Board.seq", bno);
	}

	public void write(BoardVo vo) throws Exception {
		// TODO Auto-generated method stub

		insert("Board.write", vo);
	}

	public void writeRe(BoardVo vo) throws Exception {
		// TODO Auto-generated method stub

		insert("Board.writeRe", vo);
	}

	public void update(BoardVo vo) throws Exception {
		// TODO Auto-generated method stub
		update("Board.update", vo);

	}

	public void delete(int bno) throws Exception {
		// TODO Auto-generated method stub
		update("Board.delete", bno);
	}

	public void deleteRef(int bno) throws Exception {
		// TODO Auto-generated method stub
		update("Board.deleteRef", bno);

	}

	public String check(int bno) throws Exception {
		// TODO Auto-generated method stub

		return selectOne("Board.check", bno);

	}

	public List<BoardVo> boardList(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return selectList("Board.search", cri);
	}

	public int ListCount(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return selectOne("Board.searchCount", cri);
	}

	public int refbno(int bno) throws Exception {
		// TODO Auto-generated method stub
		return selectOne("Board.refbno", bno);
	}

	public BoardVo read(int bno) throws Exception {
		update("Board.upcnt", bno);

		return selectOne("Board.read", bno);
	}

	public int count() throws Exception {
		return selectOne("Board.count");
	}

}