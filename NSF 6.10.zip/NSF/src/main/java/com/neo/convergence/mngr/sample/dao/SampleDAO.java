package com.neo.convergence.mngr.sample.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.neo.convergence.mngr.sample.model.SampleVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.mngr.sample.dao.SampleDAO<br>
 * 클래스 설명 : 샘플 DAO
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
@Repository("sampleDAO")
public class SampleDAO extends EgovAbstractMapper {

    /**
     * 샘플 개수 조회
     * @param sampleVO - 검색 조건이 담긴 VO
     * @return 샘플 개수
     */
    public int selectCntSample(SampleVO sampleVO) {
        return (Integer)selectOne("Sample.selectCntSample", sampleVO);
    }

    /**
     * 샘플 목록 조회
     * @param sampleVO - 검색 조건이 담긴 VO
     * @return 샘플 목록
     */
    public List<SampleVO> selectSampleList(SampleVO sampleVO) {
        return selectList("Sample.selectSampleList", sampleVO);
    }

    /**
     * 샘플  조회
     * @param sampleVO - 검색 조건이 담긴 VO
     * @return 샘플
     */
    public SampleVO selectSample(SampleVO sampleVO) {
        return selectOne("Sample.selectSample", sampleVO);
    }

    /**
     * 샘플 등록
     * @param sampleVO - 샘플 등록 데이터가 담긴 VO
     * @return 등록 개수
     */
    public int insertSample(SampleVO sampleVO) {
        return insert("Sample.insertSample", sampleVO);
    }

    /**
     * 샘플 수정
     * @param sampleVO - 샘플 수정 데이터가 담긴 VO
     * @return 수정 개수
     */
    public int updateSample(SampleVO sampleVO) {
        return update("Sample.updateSample", sampleVO);
    }

    /**
     * 샘플 삭제
     * @param sampleVO - 샘플 삭제 데이터가 담긴 VO
     * @return 삭제 개수
     */
    public int deleteSasmple(SampleVO sampleVO) {
        return delete("Sample.deleteSasmple", sampleVO);
    }
}