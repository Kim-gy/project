package com.neo.convergence.mngr.board.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.model.MemberVo;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("memberDao")
public class MemberDao extends EgovAbstractMapper {

	String namespace = "MemberMapper";

	public void insert(MemberVo vo) throws Exception {

		insert(namespace + ".insert", vo);
	}

	public boolean idcheck(String id) {
		if (selectOne(namespace + ".idcheck", id) != null)
			return true;
		else
			return false;

	}

	public MemberVo login(MemberVo vo) throws Exception {

		return selectOne(namespace + ".login", vo);

	}

	public List<MemberVo> list(Criteria cri) throws Exception {

		return selectList(namespace + ".list", cri);

	}

	public int count(Criteria cri) {
		return selectOne(namespace + ".count", cri);
	}

	@Override
	public int delete(String id) {
		return update(namespace + ".delete", id);

	}

	public MemberVo read(String id) {
		return selectOne(namespace + ".read", id);
	}

	public int authority(String id) {
		return selectOne(namespace + ".authority", id);
	}

	public int update(MemberVo vo) {
		return update(namespace + ".update", vo);
	}

	public int admin(String id) {
		return update(namespace + ".admin", id);
	}

	public int user(String id) {
		return update(namespace + ".user", id);
	}

	public int total() {
		return selectOne(namespace + ".total");
	}

}
