package com.neo.convergence.mngr.board.model;

import java.sql.Date;

public class DeptVo {
	@Override
	public String toString() {
		return "DeptVo [deptId=" + deptId + ", deptName=" + deptName + ", upperDeptId=" + upperDeptId + "]";
	}

	private int deptId;
	private String deptName;
	private int upperDeptId;
	private String leader;
	private String regId;
	private Date regDate;
	private String updateId;
	private Date updateDate;
	private String keyword;
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public int getUpperDeptId() {
		return upperDeptId;
	}

	public void setUpperDeptId(int upperDeptId) {
		this.upperDeptId = upperDeptId;
	}

	public String getLeader() {
		return leader;
	}

	public void setLeader(String leader) {
		this.leader = leader;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
}
