package com.neo.convergence.mngr.board.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.model.DeptVo;
import com.neo.convergence.mngr.board.model.MemberVo;
import com.neo.convergence.mngr.board.model.PageMaker;
import com.neo.convergence.mngr.board.service.DeptService;
import com.neo.convergence.mngr.board.service.MemberService;

@Controller
public class deptController {

	@Resource(name = "memberService")
	private MemberService dao;

	@Resource(name = "deptService")
	private DeptService dept;

	@RequestMapping(value = "/deptList.do", method = RequestMethod.GET)
	public String write(Model model, @RequestParam(value = "deptId", required = false) int deptId) throws Exception {
		model.addAttribute("tree", dept.tree(100));
		model.addAttribute("vo", dept.me(deptId));
		model.addAttribute("list", dept.allMem(deptId));

		return "dept";
	}

	@RequestMapping(value = "/deptLeader.do", method = RequestMethod.GET)
	public String add(Model model, @RequestParam(value = "deptId", required = false) int deptId) throws Exception {
		model.addAttribute("vo", dept.me(deptId));

		return "deptLeader";
	}

	@RequestMapping(value = "/deptLeader.do", method = RequestMethod.POST)
	public String addLEADER(DeptVo vo, MemberVo mem) throws Exception {
		dept.newLedaer(vo);
		dept.newMem(mem);

		return "redirect:deptList.do?deptId=" + vo.getDeptId();
	}

	@RequestMapping(value = "/deptAdd.do", method = RequestMethod.GET)
	public String deptadd(Model model, @RequestParam(value = "deptId", required = false) int deptId) throws Exception {
		model.addAttribute("vo", dept.me(deptId));

		return "deptAdd";
	}

	@RequestMapping(value = "/deptAdd.do", method = RequestMethod.POST)
	public String deptinsert(DeptVo vo, MemberVo mem) throws Exception {
		dept.insert(vo);

		mem.setDeptId(vo.getDeptId());

		dept.newMem(mem);
		return "redirect:deptList.do?deptId=" + vo.getUpperDeptId();
	}

	@RequestMapping(value = "/deptMem.do", method = RequestMethod.GET)
	public String deptuser(Model model, @RequestParam(value = "deptId", required = false) int deptId) throws Exception {
		model.addAttribute("vo", dept.me(deptId));

		return "deptMem";
	}

	@RequestMapping(value = "/deptMem.do", method = RequestMethod.POST)
	public String deptuserPOST(MemberVo vo, @RequestParam(value = "deptId", required = false) int deptId)
			throws Exception {
		vo.setDeptId(deptId);
		dept.newMem(vo);

		return "redirect:deptList.do?deptId=" + deptId;
	}

	@RequestMapping(value = "/deptUser.do", method = RequestMethod.GET)
	public String addDept(@RequestParam(value = "keyword", required = false) String keyword,
			@ModelAttribute("cri") Criteria cri, Model model,
			@RequestParam(value = "perPageNum", required = false) Object page) throws Exception {

		cri.setKeyword(keyword);
		model.addAttribute("list", dao.list(cri));
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(dao.count(cri));
		model.addAttribute("pageMaker", pageMaker);
		return "deptUser";
	}

	@RequestMapping(value = "deptChange.do", method = RequestMethod.GET)
	public String change(MemberVo vo, @RequestParam(value = "deptId") int deptId) throws Exception {

		dept.deptChange(vo.getId());
		return "redirect:deptList.do?deptId=" + deptId;
	}

}