package com.neo.convergence.mngr.bcnc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.bcnc.dao.BcncDAO;
import com.neo.convergence.mngr.bcnc.model.BcncVO;
import com.neo.convergence.mngr.bcnc.service.BcncService;

/**
 * ���ㅽ��紐� : �����ъ��-��濡�����2<br>
 * com.neo.convergence.mngr.bcnc.service.impl.BcncServiceImpl<br>
 * �대���� �ㅻ� : ���� Interface 援ы�� Class
 *
 * @author bcncr
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 媛����대��(Modification Infomation) >>
 *
 *      ������       ������              �����댁��
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    bcncr     理�珥�����
 * </pre>
 */
@Service("bcncService")
public class BcncServiceImpl implements BcncService {

    @SuppressWarnings("unused")
    private static final Logger LOGGER = LoggerFactory.getLogger(BcncServiceImpl.class);

    /** bcncDAO */
    @Resource(name="bcncDAO")
    private BcncDAO bcncDAO;

    @Override
    public int selectCntBcnc(BcncVO bcncVO) {
        return bcncDAO.selectCntBcnc(bcncVO);
    }

    @Override
    public List<BcncVO> selectBcncList(BcncVO bcncVO) {
        return bcncDAO.selectBcncList(bcncVO);
    }

    @Override
    public BcncVO selectBcnc(BcncVO bcncVO) {
        return bcncDAO.selectBcnc(bcncVO);
    }

    @Override
    public int insertBcnc(BcncVO bcncVO) {
        return bcncDAO.insertBcnc(bcncVO);
    }

    @Override
    public int updateBcnc(BcncVO bcncVO) {
        return bcncDAO.updateBcnc(bcncVO);
    }

	@Override
	public BcncVO selectBcncView(BcncVO searchVO) {
		//System.out.println(searchVO.toString());
		//System.out.println("BcncSn : " + searchVO.getBcncSn());
		return bcncDAO.selectBcncView(searchVO);
	}

}