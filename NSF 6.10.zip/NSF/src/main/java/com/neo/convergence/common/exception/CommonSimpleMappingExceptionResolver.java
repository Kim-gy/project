package com.neo.convergence.common.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.common.exception.CommonSimpleMappingExceptionResolver<br>
 * 클래스 설명 :
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
public class CommonSimpleMappingExceptionResolver extends SimpleMappingExceptionResolver {
    @Override
    public String buildLogMessage(Exception ex, HttpServletRequest request) {
        return "MVC exception ::" + ex.getLocalizedMessage();
    }

    @Override
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        logger.info("CustomSimpleMappingExceptionResolverrequest::"+ request.getHeader("Accept"));
        logger.error("CustomSimpleMappingExceptionResolver: " + ex.getMessage());
        String viewName = determineViewName(ex, request);
        String message = "요청 처리중 에러가 발생했습니다.";
        ModelAndView model = getModelAndView(viewName, ex, request);
        if(viewName != null) {
            String ajaxHeader = request.getHeader("X-Requested-With");
            Integer statusCode = determineStatusCode(request, viewName);
            if (ajaxHeader != null && "XMLHttpRequest".equals(ajaxHeader)) {
                if(statusCode != null) {
                    applyStatusCodeIfPossible(request, response, statusCode);
                }
            }
            String refUrl = request.getHeader("Referer");
            model.addObject("errorCode", statusCode);
            model.addObject("message", message);
            model.addObject("refUrl", refUrl);
            return model;
        } else{
            String ajaxHeader = request.getHeader("X-Requested-With");
            Integer statusCode = determineStatusCode(request, viewName);
            if (ajaxHeader != null && "XMLHttpRequest".equals(ajaxHeader)) {
                if(statusCode != null) {
                    applyStatusCodeIfPossible(request, response, statusCode);
                }
            }
            return null;
        }
    }
}
