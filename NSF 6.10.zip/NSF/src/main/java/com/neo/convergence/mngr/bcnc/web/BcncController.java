package com.neo.convergence.mngr.bcnc.web;


import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.neo.convergence.mngr.bcnc.model.BcncVO;
import com.neo.convergence.mngr.bcnc.service.BcncService;

//import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * ���ㅽ��紐� : �����ъ��-��濡�����2<br>
 * com.neo.convergence.mngr.sample.web.SampleController<br>
 * �대���� �ㅻ� : ���� Controller
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 媛����대��(Modification Infomation) >>
 *
 *      ������       ������              �����댁��
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     理�珥�����
 * </pre>
 */
@Controller
@RequestMapping(value="/mngr/bcnc")
public class BcncController {

    @SuppressWarnings("unused")
    private static final Logger LOGGER = LoggerFactory.getLogger(BcncController.class);

    /** sampleService */
    @Resource(name = "bcncService")
    BcncService bcncService;

    /**
     * 거래처 목록 조회
     * @param request
     * @param response
     * @param searchVO
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/bcncList.do")
    public String bcncList(HttpServletRequest request, HttpServletResponse response
        , @ModelAttribute("searchVO") BcncVO searchVO, Model model) throws Exception {
    	List<BcncVO> bcntList = bcncService.selectBcncList(searchVO);
    	request.setAttribute("bcntList", bcntList);

//        // set paginationInfo
//        PaginationInfo paginationInfo = new PaginationInfo();
//        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
//        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
//        paginationInfo.setPageSize(searchVO.getPageSize());

//        // get count of list, set paginationInfo
//        totCnt = sampleService.selectCntSample(searchVO);
//        paginationInfo.setTotalRecordCount(totCnt);

//        // 留�吏�留� ���댁� 蹂댁�� (����, 寃��� ��)
//        if(paginationInfo.getCurrentPageNo() != 1
//                && paginationInfo.getCurrentPageNo() > paginationInfo.getTotalPageCount()) {
//            paginationInfo.setCurrentPageNo(paginationInfo.getTotalPageCount());
//        }

//        // set paging condition
//        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
//        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
//        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
//        model.addAttribute("paginationInfo", paginationInfo);
//
//        // get list
//        List<SampleVO> sampleList = sampleService.selectSampleList(searchVO);
//        model.addAttribute("sampleList", sampleList);

        return "/mngr/bcnc/bcncList";
    }

//    @RequestMapping("/bcncView.do")
    @RequestMapping("/bcncReg.do")
    public String bcncReg(@ModelAttribute("searchForm") BcncVO searchVO) {
    	return "/mngr/bcnc/bcncReg";
    }

    @RequestMapping("/bcncRegAction.do")
    public String bcncRegAction(ModelAndView mav, BcncVO registVO) {
    	System.out.println(registVO.toString());

    	int cntInserted = bcncService.insertBcnc(registVO);
    	System.out.println(cntInserted);
        return "redirect:/mngr/bcnc/bcncList.do";
    }

    @RequestMapping("/bcncView.do")
    public String bcncView(HttpServletRequest request, HttpServletResponse response, BcncVO searchVO) {
    	BcncVO bcncView = bcncService.selectBcncView(searchVO);	// 거래처 한개 조회
//    	List<BcncVO> bcntList = bcncService.selectBcncList(searchVO);
    	//System.out.println(bcncView);
    	request.setAttribute("bcncView", bcncView);
    	return "/mngr/bcnc/bcncView";
    }
  /*  @RequestMapping("/bcncupdate.do")
    public String bcncupdate(HttpServletRequest request, HttpServletResponse response, BcncVO searchVO) {
    	BcncVO bcncupdate = bcncService.selectBcncView(searchVO);
    	request.setAttribute("bcncupdate", bcncupdate);
    	return "/mngr/bcnc/bcncupdate";
    }*/
//    @RequestMapping("/bcncMod.do")
//    @RequestMapping("/bcncModAction.do")
//    @RequestMapping("/bcncDelAction.do")
}