package com.neo.convergence.mngr.board.model;

import java.sql.Date;

public class BoardVo {
	private int num;
	private Integer bno;
	private String writer;
	private String title;
	private String content;
	private Date regdate;
	private String password;
	private int viewcnt;
	private int commentcnt;
	private Integer refbno;
	private Date updateDate;
	private String updateId;

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	private String updatedId;

	public String getUpdatedId() {
		return updatedId;
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

	public Integer getBno() {
		return bno;
	}

	public void setBno(Integer bno) {
		this.bno = bno;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getRefbno() {
		return refbno;
	}

	public int getViewcnt() {
		return viewcnt;
	}

	public void setViewcnt(int viewcnt) {
		this.viewcnt = viewcnt;
	}

	public int getCommentcnt() {
		return commentcnt;
	}

	public void setCommentcnt(int commentcnt) {
		this.commentcnt = commentcnt;
	}

	public void setRefbno(Integer refbno) {
		this.refbno = refbno;
	}

	@Override
	public String toString() {
		return "BoardVo [bno=" + bno + ", writer=" + writer + ", title=" + title + ", content=" + content + ", regdate="
				+ regdate + ", password=" + password + ", viewcnt=" + viewcnt + ", commentcnt=" + commentcnt
				+ ", refbno=" + refbno + "]";
	}
}
