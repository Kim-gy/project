package com.neo.convergence.mngr.board.service;

import com.neo.convergence.mngr.board.model.CommentVo;

public interface CommentService {

	public void deleteCas(int bno) throws Exception;

	public void write(CommentVo vo) throws Exception;

	public void upcomcnt(int bno) throws Exception;

	public void update(CommentVo vo) throws Exception;

	public CommentVo read(int cno) throws Exception;

	public String check(int cno) throws Exception;

	public void downcom(int bno) throws Exception;

	public void delete(int cno) throws Exception;

}
