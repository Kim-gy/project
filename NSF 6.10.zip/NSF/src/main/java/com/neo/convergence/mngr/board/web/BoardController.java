package com.neo.convergence.mngr.board.web;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.neo.convergence.mngr.board.model.BoardVo;
import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.model.PageMaker;
import com.neo.convergence.mngr.board.service.BoardService;

@Controller
public class BoardController {

	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(BoardController.class);

	@Resource(name = "boardService")
	BoardService ser;

	@RequestMapping(value = "/update.do", method = RequestMethod.GET)
	public String updateget(@RequestParam("bno") int bno, Model model,
			@RequestParam(value = "id", required = false) String id) throws Exception {

		model.addAttribute(ser.read(bno));
		return "update";

	}

	@RequestMapping(value = "/update.do", method = RequestMethod.POST)
	public String updatepost(@RequestParam("bno") int bno, BoardVo vo, Model model) throws Exception {

		ser.update(vo);

		return "redirect:list.do";

	}

	@RequestMapping(value = "/write.do", method = RequestMethod.GET)
	public String writeget() {

		return "write";
	}

	@RequestMapping(value = "/write.do", method = RequestMethod.POST)
	public String wrtiepost(@ModelAttribute("boardVo") BoardVo boardVo) throws Exception {
		System.out.println(boardVo.toString());

		ser.write(boardVo);

		return "redirect:list.do";
	}

	@RequestMapping(value = "/writeRe.do", method = RequestMethod.GET)
	public String writeReget(@RequestParam("refbno") int bno, Model model) throws Exception {

		model.addAttribute("refbno", bno);
		model.addAttribute(ser.read(bno));

		return "writeRe";
	}

	@RequestMapping(value = "/writeRe.do", method = RequestMethod.POST)
	public String wrtiepostRe(@ModelAttribute("boardVo") BoardVo boardVo, @RequestParam("refbno") int bno)
			throws Exception {

		boardVo.setRefbno(bno);
		System.out.println(boardVo.toString());
		ser.writeRe(boardVo);

		return "redirect:list.do";
	}

	@RequestMapping(value = "/read.do", method = RequestMethod.GET)
	public String readget(@RequestParam("bno") int bno, Model model) throws Exception {
		model.addAttribute(ser.read(bno));

		model.addAttribute("list", ser.listComment(bno));
	/*	model.addAttribute("refbno", ser.refbno(bno));*/

		return "read";
	}


	@RequestMapping(value = "/delete.do", method = RequestMethod.GET)
	public String deleteget(@RequestParam("bno") int bno, Model model) throws Exception {
		model.addAttribute("bno", bno);

		ser.delete(bno);
		ser.deleteRef(bno);
		ser.deleteCas(bno);
		return "redirect:list.do";
	}

	@RequestMapping(value = "/list.do", method = RequestMethod.GET)
	public String list(@RequestParam(value = "keyword", required = false) String keyword,
			@ModelAttribute("cri") Criteria cri, Model model, @RequestParam(value = "id", required = false) String id,
			@RequestParam(value = "perPageNum", required = false) Object page,
			@RequestParam(value = "admin", required = false) String admin) throws Exception {

		cri.setKeyword(keyword);
		if (page == null) {
			cri.setPerPageNum(0);
		} else {
			cri.setPerPageNum(Integer.parseInt((String) page));
		}
		model.addAttribute("list", ser.boardList(cri));
		System.out.println(ser.boardList(cri));
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(ser.ListCount(cri));
		model.addAttribute("pageMaker", pageMaker);
		model.addAttribute("count", ser.count());

		return "list";
	}

}
