package com.neo.convergence.mngr.board.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.neo.convergence.mngr.board.model.CommentVo;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("commentDAO")
public class CommentDao extends EgovAbstractMapper {

	String namespace = "CommentMapper";

	public void deleteCas(int bno) throws Exception {
		// TODO Auto-generated method stub
		update(namespace + ".deleteCas", bno);
	}

	public void write(CommentVo vo) throws Exception {
		// TODO Auto-generated method stub

		insert(namespace + ".write", vo);

	}

	public void upcomcnt(int bno) throws Exception {
		// TODO Auto-generated method stub

		update(namespace + ".upcomcnt", bno);

	}

	public void update(CommentVo vo) throws Exception {
		// TODO Auto-generated method stub
		update(namespace + ".update", vo);
	}

	public List<CommentVo> listComment(int refbno) throws Exception {
		// TODO Auto-generated method stub
		return selectList(namespace + ".list", refbno);
	}

	public int listCommentCount(int refbno) throws Exception {
		// TODO Auto-generated method stub
		return selectOne(namespace + ".listCount", refbno);
	}

	public CommentVo read(int cno) throws Exception {
		// TODO Auto-generated method stub
		return selectOne(namespace + ".read", cno);
	}

	public String check(int cno) throws Exception {
		// TODO Auto-generated method stub
		return selectOne(namespace + ".check", cno);
	}

	public void downcom(int bno) throws Exception {
		// TODO Auto-generated method stub
		update(namespace + ".downCom", bno);
	}

	public void delete(int cno) throws Exception {
		// TODO Auto-generated method stub
		update(namespace + ".delete", cno);
	}

}
