package com.neo.convergence.mngr.board.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.neo.convergence.mngr.board.model.CommentVo;
import com.neo.convergence.mngr.board.service.BoardService;
import com.neo.convergence.mngr.board.service.CommentService;

@Controller
public class CommentController {

	@Resource(name = "boardService")
	BoardService dao;
	@Resource(name = "commentService")
	CommentService com;

	@RequestMapping(value = "/writeCo.do", method = RequestMethod.POST)
	public String write(@ModelAttribute("CommentVo") CommentVo vo, @RequestParam("bno") int bno, Model model)
			throws Exception {
		vo.setRefbno(bno);
		com.write(vo);
		com.upcomcnt(bno);
		model.addAttribute("bno", bno);

		return "redirect:read.do";
	}

	@RequestMapping(value = "/deleteCo.do", method = RequestMethod.GET)
	public String delget(@RequestParam("cno") int cno, @RequestParam("refbno") int refbno, Model model)
			throws Exception {
		model.addAttribute("cno", cno);
		model.addAttribute("refbno", refbno);
		com.delete(cno);
		com.downcom(refbno);

		return "redirect:read.do";
	}

	@RequestMapping(value = "/deleteCo.do", method = RequestMethod.POST)
	public String delpost(@RequestParam("refbno") int refbno, @RequestParam("cno") int cno, Model model)
			throws Exception {
		model.addAttribute("refbno", refbno);
		model.addAttribute("cno", cno);
		model.addAttribute("bno", refbno);

		com.delete(cno);
		com.downcom(refbno);
		return "redirect:read.do";

	}

	@RequestMapping(value = "/updateCo.do", method = RequestMethod.GET)
	public String updateget(@RequestParam("cno") int cno, @RequestParam("refbno") int bno, Model model)
			throws Exception {

		model.addAttribute(dao.read(bno));
		model.addAttribute(com.read(cno));

		model.addAttribute("list", dao.listComment(bno));

		return "updateCo";

	}

	@RequestMapping(value = "/updateCo.do", method = RequestMethod.POST)
	public String updatepost(@RequestParam("cno") int cno, @RequestParam("refbno") int bno, CommentVo vo, Model model)
			throws Exception {
		vo.setCno(cno);
		model.addAttribute("bno", bno);

		com.update(vo);

		return "redirect:read.do";

	}
}