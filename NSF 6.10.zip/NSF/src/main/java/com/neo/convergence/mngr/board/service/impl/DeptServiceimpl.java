package com.neo.convergence.mngr.board.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.board.dao.DeptDao;
import com.neo.convergence.mngr.board.model.DeptVo;
import com.neo.convergence.mngr.board.model.MemberVo;
import com.neo.convergence.mngr.board.service.DeptService;

@Service("deptService")
public class DeptServiceimpl implements DeptService {

	@Resource(name = "deptDao")
	private DeptDao dao;

	@Override
	public void insert(DeptVo vo) throws Exception {
		// TODO Auto-generated method stub
		dao.insert(vo);
	}

	@Override
	public void newLedaer(DeptVo vo) throws Exception {
		// TODO Auto-generated method stub
		dao.newLedaer(vo);
	}

	@Override
	public List<DeptVo> Parent() throws Exception {
		return dao.Parent();

	}

	@Override
	public List<DeptVo> upper(int id) throws Exception {
		return dao.upper(id);

	}

	@Override
	public void newMem(MemberVo vo) throws Exception {
		dao.newMem(vo);

	}

	@Override
	public DeptVo me(int id) throws Exception {
		// TODO Auto-generated method stub
		return dao.me(id);
	}

	@Override
	public Map<String, DeptVo> tree(int deptId) throws Exception {
		int index = 1;
		Map<String, DeptVo> tree = new HashMap<String, DeptVo>();
		tree.put(Integer.toString(index), dao.me(deptId));
		String print = "key값:" + index + dao.me(deptId).toString();
		index = index * 10 + 1;
		int child;
		for (DeptVo i : dao.upper(deptId)) {
			print += ("key값:" + index + i.toString());

			tree.put(Integer.toString(index), i);

			if (dao.upper(i.getDeptId()) != null) {
				child = index * 10;
				for (DeptVo e : dao.upper(i.getDeptId())) {
					tree.put(Integer.toString(child), e);
					child += 1;
					print += "key값" + child + e.toString();
				}
			}
			index += 1;
			System.out.println(print);
		}
		return tree;
	}

	@Override
	public List<MemberVo> allMem(int deptId) throws Exception {

		List<MemberVo> list = new ArrayList<MemberVo>();
		list.addAll(dao.allMem(deptId));
		for (DeptVo i : dao.upper(deptId)) {
			list.addAll(dao.allMem(i.getDeptId()));
			if (dao.upper(i.getDeptId()) != null) {
				for (DeptVo e : dao.upper(i.getDeptId())) {
					list.addAll(dao.allMem(e.getDeptId()));
				}
			}
		}
		return list;
	}

	@Override
	public void deptChange(String id) throws Exception {
		// TODO Auto-generated method stub
		dao.deptChange(id);
	}

}
