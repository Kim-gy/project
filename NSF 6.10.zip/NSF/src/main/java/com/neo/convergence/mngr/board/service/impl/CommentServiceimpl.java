package com.neo.convergence.mngr.board.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.neo.convergence.mngr.board.dao.CommentDao;
import com.neo.convergence.mngr.board.model.CommentVo;
import com.neo.convergence.mngr.board.service.CommentService;
import com.neo.convergence.mngr.board.web.CommentController;

@Service("commentService")
public class CommentServiceimpl implements CommentService {

	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(CommentController.class);

	@Resource(name = "commentDAO")
	private CommentDao com;

	@Override
	public void deleteCas(int bno) throws Exception {
		// TODO Auto-generated method stub
		com.deleteCas(bno);
	}

	@Override
	public void write(CommentVo vo) throws Exception {
		// TODO Auto-generated method stub
		com.write(vo);
	}

	@Override
	public void upcomcnt(int bno) throws Exception {
		// TODO Auto-generated method stub
		com.upcomcnt(bno);
	}

	@Override
	public void update(CommentVo vo) throws Exception {
		// TODO Auto-generated method stub
		com.update(vo);
	}

	@Override
	public CommentVo read(int cno) throws Exception {
		// TODO Auto-generated method stub
		return com.read(cno);
	}

	@Override
	public String check(int cno) throws Exception {
		// TODO Auto-generated method stub
		return com.check(cno);
	}

	@Override
	public void downcom(int bno) throws Exception {
		// TODO Auto-generated method stub
		com.downcom(bno);
	}

	@Override
	public void delete(int cno) throws Exception {
		// TODO Auto-generated method stub
		com.delete(cno);
	}

}
