package com.neo.convergence.common.exception;

import egovframework.rte.fdl.cmmn.exception.handler.ExceptionHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 시스템명 : 신입사원-프로젝트2<br>
 * com.neo.convergence.common.exception.EgovOthersExcepHndlr<br>
 * 클래스 설명 :
 *
 * @author sampler
 * @since 2019. 05. 03
 * @version 1.0.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Infomation) >>
 *
 *      수정일       수정자              수정내용
 *  ------------   ----------   -------------------------------
 *  2019. 05. 03    sampler     최초생성
 * </pre>
 */
public class EgovOthersExcepHndlr implements ExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);

    /**
    * @param exception
    * @param packageName
    * @see 개발프레임웍크 실행환경 개발팀
    */
    @Override
    public void occur(Exception exception, String packageName) {
        LOGGER.debug(" EgovOthersExcepHndlr run...............");
    }

}
