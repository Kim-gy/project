package com.neo.convergence.mngr.board.web;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.neo.convergence.mngr.board.model.Criteria;
import com.neo.convergence.mngr.board.model.MemberVo;
import com.neo.convergence.mngr.board.model.PageMaker;
import com.neo.convergence.mngr.board.service.MemberService;

@Controller
public class MemberController {

	@Resource(name = "memberService")
	private MemberService dao;

	@RequestMapping(value = "/home.do", method = RequestMethod.GET)
	public String home(@RequestParam(value = "id", required = false) String id) {

		return "redirect:list.do";
	}

	@RequestMapping(value = "/deleteMem.do", method = RequestMethod.GET)
	public String del(@RequestParam(value = "id") String id) throws Exception {

		dao.delete(id);
		return "redirect:memList.do";
	}

	@RequestMapping(value = "/memList.do", method = RequestMethod.GET)
	public String memlist(@RequestParam(value = "keyword", required = false) String keyword,
			@ModelAttribute("cri") Criteria cri, Model model, @RequestParam(value = "id", required = false) String id,
			@RequestParam(value = "perPageNum", required = false) Object page) throws Exception {
		if (page == null) {
			cri.setPerPageNum(0);
		} else {
			cri.setPerPageNum(Integer.parseInt((String) page));
		}
		cri.setKeyword(keyword);
		model.addAttribute("list", dao.list(cri));
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(dao.count(cri));
		model.addAttribute("count", dao.totla());
		model.addAttribute("pageMaker", pageMaker);

		return "memList";

	}

	@RequestMapping(value = "/idcheck.do", method = RequestMethod.GET)
	public String idcheck(@RequestParam("id") String id, Model model) throws Exception {
		if (id == null) {

			model.addAttribute("message", "no");

		} else if (dao.idchek(id)) {
			model.addAttribute("message", "no");
			model.addAttribute("id", id);

		} else {
			model.addAttribute("id", id);
			model.addAttribute("message", "ok");
		}

		return "memRegister";
	}

	@RequestMapping(value = "/memRegister.do", method = RequestMethod.GET)
	public String register() {

		return "memRegister";
	}

	@RequestMapping(value = "/memRegister.do", method = RequestMethod.POST)
	public String registerpost(MemberVo vo) throws Exception {

		dao.insert(vo);

		if (vo.getRegId() == vo.getId()) {
			return "redirect:login.do";
		} else
			return "redirect:memList.do";
	}

	@RequestMapping(value = "/memUpdate.do", method = RequestMethod.GET)
	public String update(Model model, @RequestParam(value = "id", required = false) String id,
			@RequestParam(value = "login", required = false) String login) throws Exception {
		model.addAttribute("vo", dao.read(id));

		return "memUpdate";
	}

	@RequestMapping(value = "/memUpdate.do", method = RequestMethod.POST)
	public String updatePost(MemberVo vo) throws Exception {

		dao.update(vo);

		return "redirect:memList.do";
	}

	@RequestMapping(value = "/logout.do", method = RequestMethod.GET)

	public String logout(HttpServletRequest request) {
		request.getSession().removeAttribute("vo");
		request.getSession().invalidate();

		return "redirect:list.do";
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.GET)
	public String login() {

		return "login";
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public String loginpost(MemberVo vo, HttpServletResponse response, HttpServletRequest request, Model model,
			RedirectAttributes redirect) throws Exception {

		if (dao.login(vo) == null) {
			if (dao.idchek(vo.getId()) == false)
				model.addAttribute("message", "wrong id");
			else
				model.addAttribute("message", "wrong password");
			return "login";
		} else {
			HttpSession session = request.getSession();
			session.setAttribute("login", vo.getId());
			Cookie cookie = new Cookie("login", vo.getId());
			cookie.setMaxAge(60 * 60 * 24 * 7);
			cookie.setPath("/");
			response.addCookie(cookie);

			model.addAttribute("login", dao.login(vo));

			if (dao.authority(vo.getId()) == 1) {
				session.setAttribute("admin", "yes");
			}

			return "redirect:list.do";
		}
	}

	@RequestMapping(value = "/admin.do", method = RequestMethod.GET)
	public String admin(@RequestParam("id") String id) throws Exception {
		dao.admin(id);

		return "redirect:memList.do";
	}

	@RequestMapping(value = "/user.do", method = RequestMethod.GET)
	public String user(@RequestParam("id") String id) throws Exception {
		dao.user(id);

		return "redirect:memList.do";
	}

}
